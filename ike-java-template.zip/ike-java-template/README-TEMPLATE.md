# IKE Java Template

This is a template repository for creating IKE Community Java projects.

## Creating a New Project

### Option 1: GitHub Web Interface

1. Click the green **"Use this template"** button above
2. Select **"Create a new repository"**
3. Fill in your repository name and details
4. After creation, go to **Actions** tab
5. Click **"Initialize Project"** workflow
6. Click **"Run workflow"** and fill in the form
7. Wait for initialization to complete

### Option 2: GitHub CLI

```bash
gh repo create your-org/your-project \
    --template IKE-Community/ike-java-template \
    --public \
    --clone

cd your-project
./init-project.sh
```

## Initialization Inputs

| Input | Description | Example |
|-------|-------------|---------|
| Group ID | Maven group identifier | `dev.ikm.tinkar` |
| Artifact ID | Maven artifact identifier | `tinkar` |
| Version | Initial version | `1.0.0-SNAPSHOT` |
| Project Name | Human-readable name | `Tinkar` |
| Base Package | Java package base | `dev.ikm.tinkar` |

## Resulting Structure

After initialization with artifact ID `tinkar`:

```
tinkar-project/              # Root directory (aggregator POM)
├── pom.xml                  # Aggregator POM (artifactId: tinkar-project)
├── tinkar-bom/              # Bill of Materials
│   └── pom.xml
├── tinkar/                  # Code module
│   ├── pom.xml
│   └── src/
│       ├── main/java/
│       │   ├── module-info.java
│       │   └── dev/ikm/tinkar/...
│       └── test/...
└── README.md
```

## What's Included

- **Maven 4** with model version 4.1.0
- **Java 25** with preview features enabled
- **JPMS** module structure
- **BOM** for centralized dependency management
- **GitFlow** branch versioning
- **IntelliJ IDEA** settings (Google Java Style)
- **ServiceLoader** pattern example
- **SLF4J + Log4j2** logging configuration for tests

## Prerequisites

Before initializing, ensure:

1. `ike-parent` POM is published to your Maven repository
2. Java 25 is installed
3. IntelliJ IDEA 2024.3+ (for Java 25 support)
