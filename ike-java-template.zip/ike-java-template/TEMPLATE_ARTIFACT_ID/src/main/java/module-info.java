/*
 * Copyright © 2025 IKE Community (https://github.com/IKE-Community)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * TEMPLATE_PROJECT_NAME Module.
 */
module TEMPLATE_MODULE_NAME {
    requires org.slf4j;

    exports TEMPLATE_PACKAGE_NAME;
    exports TEMPLATE_PACKAGE_NAME.service;

    uses TEMPLATE_PACKAGE_NAME.service.ExampleService;
}
