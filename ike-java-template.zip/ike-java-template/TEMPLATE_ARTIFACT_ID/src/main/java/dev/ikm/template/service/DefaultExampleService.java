/*
 * Copyright © 2025 IKE Community (https://github.com/IKE-Community)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package TEMPLATE_PACKAGE_NAME.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Default implementation of {@link ExampleService}.
 *
 * <p>This implementation demonstrates basic logging and processing patterns.
 */
public class DefaultExampleService implements ExampleService {

    private static final Logger LOG = LoggerFactory.getLogger(DefaultExampleService.class);

    @Override
    public String getName() {
        return "DefaultExampleService";
    }

    @Override
    public String process(String input) {
        LOG.debug("Processing input: {}", input);
        String result = "Processed: " + input;
        LOG.info("Completed processing with result: {}", result);
        return result;
    }
}
