/*
 * Copyright © 2025 IKE Community (https://github.com/IKE-Community)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package TEMPLATE_PACKAGE_NAME.service;

/**
 * Example service interface demonstrating the ServiceLoader pattern.
 *
 * <p>Implementations of this service are discovered via {@link java.util.ServiceLoader}.
 * For production use, register implementations in {@code module-info.java} using
 * {@code provides ... with ...}. For testing, use
 * {@code META-INF/services/TEMPLATE_PACKAGE_NAME.service.ExampleService}.
 */
public interface ExampleService {

    /**
     * Returns the name of this service implementation.
     *
     * @return the service name
     */
    String getName();

    /**
     * Performs the example operation.
     *
     * @param input the input value
     * @return the processed result
     */
    String process(String input);
}
