/*
 * Copyright © 2025 IKE Community (https://github.com/IKE-Community)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package TEMPLATE_PACKAGE_NAME.service;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ServiceLoader;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for {@link ExampleService} implementations.
 *
 * <p>Demonstrates ServiceLoader discovery using META-INF/services in test resources.
 */
class ExampleServiceTest {

    private static final Logger LOG = LoggerFactory.getLogger(ExampleServiceTest.class);

    @Test
    void shouldDiscoverServiceViaServiceLoader() {
        // Given: ServiceLoader configured via META-INF/services
        ServiceLoader<ExampleService> loader = ServiceLoader.load(ExampleService.class);

        // When: Loading services
        var services = loader.stream().toList();

        // Then: At least one implementation is found
        LOG.info("Discovered {} ExampleService implementation(s)", services.size());
        assertFalse(services.isEmpty(), "Expected at least one ExampleService implementation");

        // And: The default implementation is available
        ExampleService service = services.getFirst().get();
        assertEquals("DefaultExampleService", service.getName());
    }

    @Test
    void shouldProcessInput() {
        // Given: A service instance
        ExampleService service = new DefaultExampleService();

        // When: Processing input
        String result = service.process("test input");

        // Then: Result is as expected
        assertEquals("Processed: test input", result);
    }

    @Test
    void defaultServiceShouldHaveCorrectName() {
        // Given: The default service implementation
        ExampleService service = new DefaultExampleService();

        // When/Then: Name is correct
        assertEquals("DefaultExampleService", service.getName());
    }
}
