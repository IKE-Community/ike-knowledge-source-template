#!/bin/bash
# init-project.sh - Initialize project from IKE Java template
# Run once after creating repository from template, then this script self-destructs.

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}╔════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   IKE Java Project Initialization Wizard   ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════╝${NC}"
echo ""

# Check if already initialized
if [ ! -f "pom.xml" ] || ! grep -q "TEMPLATE_ARTIFACT_ID" pom.xml 2>/dev/null; then
    echo -e "${RED}Error: Project appears to already be initialized.${NC}"
    echo "If this is incorrect, restore pom.xml from the template."
    exit 1
fi

# Gather inputs
echo -e "${BLUE}Please provide project information:${NC}"
echo ""

read -p "Maven Group ID [dev.ikm]: " GROUP_ID
GROUP_ID=${GROUP_ID:-dev.ikm}

read -p "Maven Artifact ID (e.g., my-project): " ARTIFACT_ID
if [ -z "$ARTIFACT_ID" ]; then
    echo -e "${RED}Error: Artifact ID is required${NC}"
    exit 1
fi

# Validate artifact_id
if [[ ! "$ARTIFACT_ID" =~ ^[a-z][a-z0-9-]*$ ]]; then
    echo -e "${RED}Error: Artifact ID must be lowercase alphanumeric with hyphens${NC}"
    exit 1
fi

read -p "Version [1.0.0-SNAPSHOT]: " VERSION
VERSION=${VERSION:-1.0.0-SNAPSHOT}

read -p "Project Display Name [$ARTIFACT_ID]: " PROJECT_NAME
PROJECT_NAME=${PROJECT_NAME:-$ARTIFACT_ID}

read -p "Base Java Package [${GROUP_ID}]: " BASE_PACKAGE
BASE_PACKAGE=${BASE_PACKAGE:-$GROUP_ID}

# Validate base_package
if [[ ! "$BASE_PACKAGE" =~ ^[a-z][a-z0-9.]*$ ]]; then
    echo -e "${RED}Error: Base package must be lowercase with dots${NC}"
    exit 1
fi

# Derive values
PACKAGE_PATH="${BASE_PACKAGE//./\/}"
MODULE_NAME="$BASE_PACKAGE"

echo ""
echo -e "${BLUE}Configuration:${NC}"
echo "  Group ID:      $GROUP_ID"
echo "  Artifact ID:   $ARTIFACT_ID"
echo "  Version:       $VERSION"
echo "  Display Name:  $PROJECT_NAME"
echo "  Base Package:  $BASE_PACKAGE"
echo "  Module Name:   $MODULE_NAME"
echo ""
echo "  Project structure:"
echo "    ${ARTIFACT_ID}-project/     (aggregator)"
echo "    ├── ${ARTIFACT_ID}-bom/     (BOM)"
echo "    └── ${ARTIFACT_ID}/         (code module)"
echo ""

read -p "Proceed with initialization? [Y/n]: " CONFIRM
CONFIRM=${CONFIRM:-Y}
if [[ ! "$CONFIRM" =~ ^[Yy]$ ]]; then
    echo "Aborted."
    exit 0
fi

echo ""
echo -e "${BLUE}Initializing project...${NC}"

# 1. Rename module directories
echo "  Renaming module directories..."
mv "TEMPLATE_ARTIFACT_ID" "${ARTIFACT_ID}"
mv "TEMPLATE_ARTIFACT_ID-bom" "${ARTIFACT_ID}-bom"

# 2. Create package directories
echo "  Creating package directories..."
mkdir -p "${ARTIFACT_ID}/src/main/java/${PACKAGE_PATH}/service"
mkdir -p "${ARTIFACT_ID}/src/test/java/${PACKAGE_PATH}/service"
mkdir -p "${ARTIFACT_ID}/src/test/resources/META-INF/services"

# 3. Move source files
echo "  Moving source files..."
# Main sources
for file in "${ARTIFACT_ID}/src/main/java/dev/ikm/template/"*.java 2>/dev/null; do
    [ -f "$file" ] && mv "$file" "${ARTIFACT_ID}/src/main/java/${PACKAGE_PATH}/"
done
for file in "${ARTIFACT_ID}/src/main/java/dev/ikm/template/service/"*.java 2>/dev/null; do
    [ -f "$file" ] && mv "$file" "${ARTIFACT_ID}/src/main/java/${PACKAGE_PATH}/service/"
done

# Test sources
for file in "${ARTIFACT_ID}/src/test/java/dev/ikm/template/service/"*.java 2>/dev/null; do
    [ -f "$file" ] && mv "$file" "${ARTIFACT_ID}/src/test/java/${PACKAGE_PATH}/service/"
done

# Remove old template directories
rm -rf "${ARTIFACT_ID}/src/main/java/dev"
rm -rf "${ARTIFACT_ID}/src/test/java/dev"

# 4. Rename ServiceLoader file
echo "  Updating ServiceLoader registration..."
OLD_SERVICE_FILE="${ARTIFACT_ID}/src/test/resources/META-INF/services/TEMPLATE_PACKAGE_NAME.service.ExampleService"
NEW_SERVICE_FILE="${ARTIFACT_ID}/src/test/resources/META-INF/services/${BASE_PACKAGE}.service.ExampleService"
if [ -f "$OLD_SERVICE_FILE" ]; then
    mv "$OLD_SERVICE_FILE" "$NEW_SERVICE_FILE"
fi

# 5. Replace placeholders in all files
echo "  Replacing placeholders..."
find . -type f \( \
    -name "*.xml" -o \
    -name "*.java" -o \
    -name "*.md" -o \
    -name "*.properties" -o \
    -name "*.yml" -o \
    -name "*.yaml" \
\) -not -path "./.git/*" -exec sed -i.bak \
    -e "s/TEMPLATE_GROUP_ID/$GROUP_ID/g" \
    -e "s/TEMPLATE_ARTIFACT_ID/$ARTIFACT_ID/g" \
    -e "s/TEMPLATE_VERSION/$VERSION/g" \
    -e "s/TEMPLATE_PROJECT_NAME/$PROJECT_NAME/g" \
    -e "s/TEMPLATE_PACKAGE_NAME/$BASE_PACKAGE/g" \
    -e "s/TEMPLATE_MODULE_NAME/$MODULE_NAME/g" \
    {} \;

# Update ServiceLoader file content
if [ -f "$NEW_SERVICE_FILE" ]; then
    sed -i.bak "s/TEMPLATE_PACKAGE_NAME/$BASE_PACKAGE/g" "$NEW_SERVICE_FILE"
fi

# Remove backup files
find . -name "*.bak" -delete

# 6. Clean up template files
echo "  Cleaning up template files..."
rm -f init-project.sh
rm -f README-TEMPLATE.md
rm -f .github/workflows/init-project.yml

if [ -f ".github/PROJECT-README.md" ]; then
    mv .github/PROJECT-README.md README.md
fi

# 7. Stage changes
echo "  Staging changes..."
git add -A

echo ""
echo -e "${GREEN}╔════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   Project initialized successfully!        ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════╝${NC}"
echo ""
echo "Next steps:"
echo "  1. Review staged changes: git status"
echo "  2. Commit: git commit -m 'Initialize ${ARTIFACT_ID} from IKE template'"
echo "  3. Ensure ike-parent is published to your Maven repository"
echo "  4. Build: ./mvnw clean install"
echo ""
echo "To start a feature branch:"
echo "  ./mvnw gitflow:feature-start -DfeatureName=my-feature"
echo ""
