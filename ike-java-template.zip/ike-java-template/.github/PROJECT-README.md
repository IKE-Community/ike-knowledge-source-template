# TEMPLATE_PROJECT_NAME

TEMPLATE_PROJECT_NAME - An IKE Community Project

## Building

### Prerequisites

- Java 25
- Maven 4 (via wrapper)

### Build Commands

```bash
# Full build
./mvnw clean install

# Skip tests
./mvnw clean install -DskipTests

# Run specific test
./mvnw test -pl TEMPLATE_ARTIFACT_ID -Dtest=ExampleServiceTest
```

## Project Structure

```
TEMPLATE_ARTIFACT_ID-project/         # Root aggregator
├── pom.xml                           # Aggregator POM
├── TEMPLATE_ARTIFACT_ID-bom/         # Bill of Materials
│   └── pom.xml                       # Dependency version management
├── TEMPLATE_ARTIFACT_ID/             # Main code module
│   ├── pom.xml
│   └── src/
│       ├── main/java/
│       │   ├── module-info.java
│       │   └── TEMPLATE_PACKAGE_NAME/
│       └── test/
│           ├── java/
│           └── resources/
│               ├── log4j2-test.xml
│               └── META-INF/services/
└── README.md
```

## Modules

| Module | Description |
|--------|-------------|
| `TEMPLATE_ARTIFACT_ID-bom` | Bill of Materials - centralized dependency versions |
| `TEMPLATE_ARTIFACT_ID` | Main code module |

## GitFlow Commands

```bash
# Start a feature branch
./mvnw gitflow:feature-start -DfeatureName=my-feature

# Finish a feature
./mvnw gitflow:feature-finish

# Start a release
./mvnw gitflow:release-start

# Finish a release
./mvnw gitflow:release-finish
```

## Adding Dependencies

Add new dependencies to the BOM (`TEMPLATE_ARTIFACT_ID-bom/pom.xml`):

```xml
<dependencyManagement>
    <dependencies>
        <dependency>
            <groupId>com.example</groupId>
            <artifactId>example-library</artifactId>
            <version>${example.version}</version>
        </dependency>
    </dependencies>
</dependencyManagement>
```

Then use in modules without specifying version:

```xml
<dependency>
    <groupId>com.example</groupId>
    <artifactId>example-library</artifactId>
</dependency>
```

## License

Apache License, Version 2.0
